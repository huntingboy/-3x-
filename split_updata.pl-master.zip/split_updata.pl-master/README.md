splitupdate (formerly split_updata.pl)
===============

Improved tool for splitting UPDATE.APP for Huawei phones

To extract execute:
```
chmod +x splitupdate
./splitupdate UPDATE.APP
```

The img files will be extracted in the /output/ folder.
